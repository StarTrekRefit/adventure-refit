ST REFIT: ADVENTURE  -  version 0.9.02 (public beta)
================================================

A new engine for Star Trek: 25th Anniversary. It runs the game from your
own copy, reading the original files. Judgment Rites (CD-ROM, English)
runs from the same start screen, marked Experimental.

Refit includes none of the game's files. You need your own copy of the
game (GOG, Steam, or the original CD-ROM or floppy).

Discord (downloads, help, bug reports, ideas):
https://discord.gg/M4CFYX2zGj


QUICK START
-----------
1. Unzip this folder anywhere. There is no installer.
2. Start the program.
3. On the start screen, add your game folder or disc image.
4. Play. F10 switches between Classic and Enhanced at any time
   (25th Anniversary only).


WHICH VERSIONS OF THE GAME WORK
-------------------------------
- The CD-ROM edition, as a folder or a disc image
- The GOG release, in English, French or German
- The floppy edition (1.0)
- The Steam release has not been tested yet

If Refit doesn't recognize your copy, it says so and writes a small text
file called unsupported-edition-<code>.txt next to the program. Post that
file in #adventure-chat on the Discord.


FIRST START ON WINDOWS
----------------------
Refit is not code-signed, so Windows may warn you the first time.
Choose "More info", then "Run anyway".
Only download Refit from the #downloads channel on the Discord.


FIRST START ON MAC  (UNTESTED BUILD)
------------------------------------
The Mac build is not signed with an Apple certificate.
Try to open it once. Then go to System Settings > Privacy & Security,
scroll down and click "Open Anyway". You only need to do this once.


FIRST START ON LINUX  (UNTESTED BUILD)
--------------------------------------
If the program won't start, mark it as executable: right-click the file,
choose Properties > Permissions, and allow it to run as a program.


MAC AND LINUX
-------------
The Mac and Linux builds come from the same code as the Windows build,
but nobody has tested them yet. Please tell us on the Discord how they run.
MT-32 music works on Windows only. On Mac and Linux, AdLib is the only
music choice.


CLASSIC AND ENHANCED
--------------------
Classic is the game as it shipped. Enhanced adds widescreen, the
viewscreen, new planets and more, and each extra has its own switch in
the options. Refit starts in Enhanced, with the wide screen on. F10
swaps between the two (25th Anniversary only; Judgment Rites runs in
Classic). The original bug fixes apply in both modes. Refit never
changes your game files, and your old saves can be loaded.


MT-32 MUSIC (WINDOWS ONLY)
--------------------------
Put your own Roland MT-32 (or CM-32L) ROM files in the "MT-32 ROMs"
folder next to the program. You need a control ROM and a PCM ROM; any
file names work, because Refit recognizes them by their contents. The
Sound page has a button that opens the folder. Then pick MT-32 as the
music source. Refit does not include any ROMs.

Have a real MT-32 (or CM-32L)? Connect it through a MIDI interface and
pick it under Music source, where every MIDI device Windows knows is
listed as "MIDI: <its name>". Music starts after a few seconds, while
the MT-32 is set up.


REPORTING A BUG
---------------
Make a post in #adventure-bugs on the Discord and attach your log file,
STARefit.log. The newest log is the one called STARefit.log; older
sessions are kept beside it with the date in their name.

Where the log is:
  Windows:  %APPDATA%\ST Refit Adventure\logs
            (paste that into the File Explorer address bar)
  Mac:      ~/Library/Application Support/ST Refit Adventure/logs
  Linux:    ~/.local/share/ST Refit Adventure/logs


WHERE YOUR SETTINGS AND SAVES ARE
---------------------------------
Refit keeps its settings and saved games in the same "ST Refit Adventure"
folder as the log:
  Windows:  %APPDATA%\ST Refit Adventure
  Mac:      ~/Library/Application Support/ST Refit Adventure
  Linux:    ~/.local/share/ST Refit Adventure
The "MT-32 ROMs" folder stays next to the program. On the Mac, or if the
program's folder can't be written to, it goes in the folder above instead.


ABOUT
-----
ST Refit: Adventure is free, with no donations. It is a fan project, not
connected with or endorsed by Paramount, CBS Studios or Interplay.
Star Trek and all related marks, logos and characters are solely owned
by CBS Studios Inc.
The 3D ship models are by Major Stress, used under CC BY 4.0.
Third-party notices are in Appendix.txt.
