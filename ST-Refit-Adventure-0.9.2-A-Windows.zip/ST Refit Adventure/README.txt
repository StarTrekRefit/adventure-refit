ST REFIT: ADVENTURE  -  version 0.9.2-A (test build)
================================================

A new engine for Star Trek: 25th Anniversary. It runs the game from your
own copy, reading the original files. Judgment Rites (CD-ROM, English)
runs from the same start screen, marked Experimental.

Refit includes none of the game's files. You need your own copy of the
game (GOG, Steam, or the original CD-ROM or floppy).

Discord (downloads, help, bug reports, ideas):
https://discord.gg/M4CFYX2zGj


QUICK START
-----------
1. Unzip this folder anywhere. There is no installer.
2. Start the program.
3. On the start screen, add your game folder or disc image.
4. Play. F10 switches between Classic and Enhanced at any time
   (25th Anniversary only).


WHICH VERSIONS OF THE GAME WORK
-------------------------------
- The CD-ROM edition, as a folder or a disc image
- The GOG release, in English, French or German
  (adding the GOG folder adds all three; French and German play
  with the original English voices)
- The floppy edition (1.0, the UK release, and the one in
  Interplay's 10 Year Anthology)
- The Mac edition (the original floppy release: its StuffIt archive
  or the folder unpacked on a Mac)
- The Steam release has not been tested yet

If Refit doesn't recognize your copy, it says so and writes a small text
file called unsupported-edition-<code>.txt next to the program. Post that
file in #adventure-chat on the Discord.


FIRST START ON WINDOWS
----------------------
Refit is not code-signed, so Windows may warn you the first time.
Choose "More info", then "Run anyway".
Only download Refit from the #downloads channel on the Discord.


FIRST START ON MAC  (UNTESTED BUILD)
------------------------------------
The Mac build is not signed with an Apple certificate.
Try to open it once. Then go to System Settings > Privacy & Security,
scroll down and click "Open Anyway". You only need to do this once.


FIRST START ON LINUX  (UNTESTED BUILD)
--------------------------------------
If the program won't start, mark it as executable: right-click the file,
choose Properties > Permissions, and allow it to run as a program.


MAC AND LINUX
-------------
The Mac and Linux builds come from the same code as the Windows build,
but nobody has tested them yet. Please tell us on the Discord how they run.
MT-32 music works on Windows only. On Mac and Linux, AdLib is the only
music choice.


CLASSIC AND ENHANCED
--------------------
Classic is the game as it shipped. Enhanced adds widescreen, the
viewscreen, new planets and more, and each extra has its own switch in
the options. Refit starts in Enhanced, with the wide screen on. F10
swaps between the two (25th Anniversary only; Judgment Rites runs in
Classic). The original bug fixes apply in both modes. Refit never
changes your game files, and your old saves can be loaded.


MT-32 MUSIC (WINDOWS ONLY)
--------------------------
Put your own Roland MT-32 (or CM-32L) ROM files in the "MT-32 ROMs"
folder next to the program. You need a control ROM and a PCM ROM; any
file names work, because Refit recognizes them by their contents. The
Sound page has a button that opens the folder. Then pick MT-32 as the
music source. Refit does not include any ROMs.

Have a real MT-32 (or CM-32L)? Connect it through a MIDI interface and
pick it under Music source, where every MIDI device Windows knows is
listed as "MIDI: <its name>". Music starts after a few seconds, while
the MT-32 is set up.


YOUR OWN MUSIC (ENHANCED)
-------------------------
You can replace any of the game's music with your own OGG, MP3 or WAV
files. Select your game on the start screen and choose Music. For each
piece you can hear the original, pick a file, set where your cut starts
and ends, and listen to it before you save. Pieces you don't replace
keep the original music, and sound effects are never replaced. Your
music plays in Enhanced only; "Use custom music" turns it all off.

The files are kept in the "Music" folder next to the program (Music\st25).
You can also put files there yourself, named after the piece they
replace, for example battle-1.ogg; they play whole. The names are:
  title, mission-opening, warp, evaluation-poor, evaluation-perfect,
  bridge-ambience, comic-moment, red-alert, battle-1, battle-2,
  battle-3, victory, enterprise-lost, away-00, away-02, away-24,
  away-27, away-29, away-31, away-32
  Floppy copy only: away-15


CASUAL MODE (NO SHIP COMBAT)
----------------------------
Want the story without the space battles? In the game list, click the
gear next to Play and pick "Casual (no ship combat)". Play itself always
starts a normal game.

In casual mode the battles the story sends you into are left out or shown
as a short scene that you win. A battle you bring on yourself, by flying
to the wrong star or by a wrong answer, is still a real one.

A saved game remembers its mode: casual saves have "Casual" in their name,
and loading a save switches to the mode it was saved in.


REPORTING A BUG
---------------
Make a post in #adventure-bugs on the Discord and attach your log file,
STARefit.log. The newest log is the one called STARefit.log; older
sessions are kept beside it with the date in their name.

Where the log is:
  Windows:  %APPDATA%\ST Refit Adventure\logs
            (paste that into the File Explorer address bar)
  Mac:      ~/Library/Application Support/ST Refit Adventure/logs
  Linux:    ~/.local/share/ST Refit Adventure/logs


DETAILED LOG FOR TESTERS
------------------------
If we ask you for a detailed log, start Refit with "--log" after its name.
On Windows: right-click the program, choose "Create shortcut", then
right-click the new shortcut and choose Properties. In "Target", add a
space and --log at the very end, after the closing quote, and click OK.
Start the game from that shortcut and play until the problem happens.

The log file then also lists what the game is doing: rooms, text, sounds
and music (and why one didn't play), animations, walking, and in space
battles every ship once a second plus every shot, hit, damage and repair.
It is the same STARefit.log file as always, only longer.


WHERE YOUR SETTINGS AND SAVES ARE
---------------------------------
Refit keeps its settings and saved games in the same "ST Refit Adventure"
folder as the log:
  Windows:  %APPDATA%\ST Refit Adventure
  Mac:      ~/Library/Application Support/ST Refit Adventure
  Linux:    ~/.local/share/ST Refit Adventure
The "MT-32 ROMs" folder stays next to the program. On the Mac, or if the
program's folder can't be written to, it goes in the folder above instead.


ABOUT
-----
ST Refit: Adventure is free, with no donations. It is a fan project, not
connected with or endorsed by Paramount, CBS Studios or Interplay.
Star Trek and all related marks, logos and characters are solely owned
by CBS Studios Inc.
The 3D ship models are by Major Stress, used under CC BY 4.0.
Third-party notices are in Appendix.txt.
